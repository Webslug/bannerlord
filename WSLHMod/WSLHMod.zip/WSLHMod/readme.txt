This Bannerlord mod adds a number of dialogue options to adjust relationships with characters found in the world.

[b]Goal[/b]
I found the cheat menu did not give me granular control over relationships in the game, it was entertaining to have rivals and allies. The purpose of the mod grants the player the capability to modify the relationships of those around them for more intriguing game play.

[b]Difficulty / Balance[/b]
Obviously this mod distorts the difficulty of the game however I often used to despise building relationships in Warband.  Hopefully it helps others in their enjoyment of the game too.

[b]Updates[/b]
Alpha prototype.  Possible future updates...

[b]Requirements[/b]
* Harmony
* MCM5

[b]Buy me a Coffee[/b]
https://bmc.link/reloadedx2y

[b]Known Bugs[/b]
Works with all most characters except for un-landed roaming vassals.

[b]Restrictions[/b]
Disabled when interacting with fugitives.